"""
실험 Python 코드 / Experimental Python Code
Topic: Blockchain-Based Trusted On-Chain Evidence Preservation and Anti-Tampering Mechanism for YOLO Detection Results

This script is organized according to the paper's experiment section:
1) EvidencePayload data structure
2) YOLOv8 inference + immediate SHA-256/ECDSA signing
3) Local SQLite evidence storage
4) Merkle batch aggregation
5) Tampering detection experiment
6) Performance latency/FPS experiment

Notes:
- This version is designed as a reproducible local experiment.
- Blockchain submission is implemented as an optional placeholder because Sepolia RPC,
  contract ABI, and private keys must be provided by the researcher.
- IPFS upload is also optional; local experiments use ipfs_cid="local_only".
"""

import os
import cv2
import json
import time
import glob
import sqlite3
import hashlib
import datetime
import argparse
import statistics
from dataclasses import dataclass
from typing import List, Tuple, Dict, Any

try:
    from ultralytics import YOLO
except ImportError:
    YOLO = None

try:
    from eth_keys.datatypes import PrivateKey
    from eth_keys import keys as eth_keys
except ImportError:
    PrivateKey = None
    eth_keys = None


# ============================================================
# 1. EvidencePayload Data Structure
# ============================================================

@dataclass
class Detection:
    """Single YOLO detection result."""
    x1: float
    y1: float
    x2: float
    y2: float
    confidence: float
    class_id: int
    class_name: str


@dataclass
class EvidencePayload:
    """Evidence payload bound to one inference frame."""
    frame_id: int
    timestamp: str
    device_id: str
    gps_coords: Tuple[float, float, float]
    ipfs_cid: str
    detections: List[Detection]
    frame_hash: str
    payload_hash: str = ""
    nonce: int = 0
    ecdsa_sig: str = ""

    def canonical_json(self) -> str:
        """Deterministic JSON serialization: sorted keys and no whitespace."""
        data = {
            "frame_id": self.frame_id,
            "timestamp": self.timestamp,
            "device_id": self.device_id,
            "gps_coords": list(self.gps_coords),
            "ipfs_cid": self.ipfs_cid,
            "detections": [
                {
                    "x1": round(d.x1, 6),
                    "y1": round(d.y1, 6),
                    "x2": round(d.x2, 6),
                    "y2": round(d.y2, 6),
                    "conf": round(d.confidence, 6),
                    "cls": d.class_id,
                    "name": d.class_name,
                }
                for d in sorted(self.detections, key=lambda x: (x.class_id, x.confidence))
            ],
            "frame_hash": self.frame_hash,
            "nonce": self.nonce,
        }
        return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

    def compute_payload_hash(self) -> str:
        return hashlib.sha256(self.canonical_json().encode("utf-8")).hexdigest()

    def to_db_tuple(self):
        return (
            self.frame_id,
            self.timestamp,
            self.device_id,
            str(self.gps_coords),
            self.ipfs_cid,
            self.canonical_json(),
            self.frame_hash,
            self.payload_hash,
            self.nonce,
            self.ecdsa_sig,
        )


# ============================================================
# 2. YOLOv8 Inference + Immediate Signing
# ============================================================

class InferenceSigner:
    """YOLOv8 inference + immediate SHA-256/ECDSA evidence signing."""

    def __init__(self, model_path: str, private_key_hex: str, device_id: str):
        if YOLO is None:
            raise ImportError("Please install ultralytics: pip install ultralytics")
        if PrivateKey is None:
            raise ImportError("Please install eth-keys: pip install eth-keys")

        self.model = YOLO(model_path)
        self.private_key = PrivateKey(bytes.fromhex(private_key_hex.replace("0x", "")))
        self.device_id = device_id
        self.frame_counter = 0
        self.nonce = 0

    def process_frame(self, frame, gps=(35.1796, 129.0756, 0.0)) -> Tuple[EvidencePayload, float]:
        start = time.perf_counter()

        results = self.model(frame, verbose=False)
        detections = self._parse_results(results)

        ok, encoded = cv2.imencode(".jpg", frame)
        if not ok:
            raise ValueError("Failed to encode frame as JPG.")
        frame_bytes = encoded.tobytes()
        frame_hash = hashlib.sha256(frame_bytes).hexdigest()

        self.frame_counter += 1
        self.nonce += 1

        payload = EvidencePayload(
            frame_id=self.frame_counter,
            timestamp=datetime.datetime.utcnow().isoformat() + "Z",
            device_id=self.device_id,
            gps_coords=gps,
            ipfs_cid="local_only",
            detections=detections,
            frame_hash=frame_hash,
            nonce=self.nonce,
        )

        payload.payload_hash = payload.compute_payload_hash()
        sig = self.private_key.sign_msg_hash(bytes.fromhex(payload.payload_hash))
        payload.ecdsa_sig = sig.to_hex()

        latency_ms = (time.perf_counter() - start) * 1000
        return payload, latency_ms

    def _parse_results(self, results) -> List[Detection]:
        detections = []
        for r in results:
            if r.boxes is None:
                continue
            for box in r.boxes:
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                class_id = int(box.cls[0])
                detections.append(
                    Detection(
                        x1=x1,
                        y1=y1,
                        x2=x2,
                        y2=y2,
                        confidence=float(box.conf[0]),
                        class_id=class_id,
                        class_name=r.names[class_id],
                    )
                )
        return detections


# ============================================================
# 3. Local SQLite Evidence Store
# ============================================================

class EvidenceStore:
    """Immediate local evidence preservation using SQLite WAL mode."""

    def __init__(self, db_path: str = "evidence.db"):
        self.conn = sqlite3.connect(db_path)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self._init_db()

    def _init_db(self):
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS evidence (
                frame_id INTEGER PRIMARY KEY,
                timestamp TEXT NOT NULL,
                device_id TEXT NOT NULL,
                gps_coords TEXT NOT NULL,
                ipfs_cid TEXT NOT NULL,
                detections_json TEXT NOT NULL,
                frame_hash TEXT NOT NULL,
                payload_hash TEXT NOT NULL UNIQUE,
                nonce INTEGER NOT NULL,
                ecdsa_sig TEXT NOT NULL
            )
            """
        )
        self.conn.commit()

    def store_local(self, payload: EvidencePayload) -> float:
        start = time.perf_counter()
        self.conn.execute(
            "INSERT OR REPLACE INTO evidence VALUES (?,?,?,?,?,?,?,?,?,?)",
            payload.to_db_tuple(),
        )
        self.conn.commit()
        return (time.perf_counter() - start) * 1000


# ============================================================
# 4. Merkle Batch Aggregation
# ============================================================

def sha256_hex(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def build_merkle_root(leaves: List[str]) -> str:
    """Build a simple SHA-256 Merkle root from hex string leaves."""
    if not leaves:
        return ""
    level = leaves[:]
    while len(level) > 1:
        if len(level) % 2 == 1:
            level.append(level[-1])
        next_level = []
        for i in range(0, len(level), 2):
            combined = level[i] + level[i + 1]
            next_level.append(sha256_hex(combined))
        level = next_level
    return level[0]


# ============================================================
# 5. Verification and Tampering Detection
# ============================================================

class EvidenceVerifier:
    """Verify payload hash and ECDSA signature in local experiment mode."""

    @staticmethod
    def verify_payload_hash(payload: EvidencePayload) -> bool:
        return payload.compute_payload_hash() == payload.payload_hash

    @staticmethod
    def verify_signature(payload: EvidencePayload, public_key_hex: str) -> bool:
        if eth_keys is None:
            raise ImportError("Please install eth-keys: pip install eth-keys")
        public_key = eth_keys.PublicKey(bytes.fromhex(public_key_hex.replace("0x", "")))
        sig = eth_keys.Signature(bytes.fromhex(payload.ecdsa_sig.replace("0x", "")))
        return public_key.verify_msg_hash(bytes.fromhex(payload.payload_hash), sig)


def tampering_experiment(payload: EvidencePayload, public_key_hex: str) -> Dict[str, Any]:
    """Run three simple tampering tests: bit/content, field, and record substitution."""
    verifier = EvidenceVerifier()
    original_ok = verifier.verify_payload_hash(payload) and verifier.verify_signature(payload, public_key_hex)

    # Field-level modification: change confidence
    tampered = EvidencePayload(**payload.__dict__)
    tampered.detections = [Detection(**d.__dict__) for d in payload.detections]
    if tampered.detections:
        tampered.detections[0].confidence = min(0.999999, tampered.detections[0].confidence + 0.01)
    else:
        tampered.ipfs_cid = "tampered_cid"

    tampered_hash_ok = verifier.verify_payload_hash(tampered)

    return {
        "original_verification": original_ok,
        "tampered_payload_hash_passed": tampered_hash_ok,
        "tampering_detected": not tampered_hash_ok,
    }


# ============================================================
# 6. Experimental Runner
# ============================================================

def load_images(image_dir: str) -> List[str]:
    exts = ["*.jpg", "*.jpeg", "*.png", "*.bmp"]
    paths = []
    for ext in exts:
        paths.extend(glob.glob(os.path.join(image_dir, ext)))
    return sorted(paths)


def run_experiment(args):
    private_key_hex = args.private_key
    device_id = hashlib.sha256(args.device_cert.encode("utf-8")).hexdigest()

    signer = InferenceSigner(args.model, private_key_hex, device_id)
    store = EvidenceStore(args.db)
    public_key_hex = signer.private_key.public_key.to_hex()

    image_paths = load_images(args.image_dir)[: args.limit]
    if not image_paths:
        raise FileNotFoundError(f"No images found in {args.image_dir}")

    infer_latencies = []
    store_latencies = []
    payload_hashes = []
    tamper_results = []

    total_start = time.perf_counter()
    for idx, path in enumerate(image_paths, 1):
        frame = cv2.imread(path)
        if frame is None:
            continue

        payload, infer_ms = signer.process_frame(frame)
        store_ms = store.store_local(payload)
        tamper_result = tampering_experiment(payload, public_key_hex)

        infer_latencies.append(infer_ms)
        store_latencies.append(store_ms)
        payload_hashes.append(payload.payload_hash)
        tamper_results.append(tamper_result["tampering_detected"])

        print(f"[{idx}/{len(image_paths)}] frame_id={payload.frame_id}, infer+sign={infer_ms:.3f} ms, sqlite={store_ms:.3f} ms, tamper_detected={tamper_result['tampering_detected']}")

    total_time = time.perf_counter() - total_start
    fps = len(infer_latencies) / total_time if total_time > 0 else 0
    merkle_root = build_merkle_root(payload_hashes)
    detection_rate = sum(tamper_results) / len(tamper_results) * 100 if tamper_results else 0

    print("\n================ Experiment Summary ================")
    print(f"Images processed: {len(infer_latencies)}")
    print(f"FPS: {fps:.2f}")
    print(f"Inference + signing latency mean: {statistics.mean(infer_latencies):.3f} ms")
    print(f"Local SQLite latency mean: {statistics.mean(store_latencies):.3f} ms")
    print(f"Tampering detection rate: {detection_rate:.2f}%")
    print(f"Merkle root: {merkle_root}")
    print("====================================================")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="YOLO Blockchain Evidence Preservation Experiment")
    parser.add_argument("--model", default="yolov8n.pt", help="YOLOv8 model path, e.g., yolov8n.pt")
    parser.add_argument("--image_dir", required=True, help="Directory containing experiment images")
    parser.add_argument("--limit", type=int, default=100, help="Maximum number of images to process")
    parser.add_argument("--db", default="evidence.db", help="SQLite database path")
    parser.add_argument("--device_cert", default="camera_cert_demo_001", help="Simulated camera certificate string")
    parser.add_argument(
        "--private_key",
        default="1" * 64,
        help="64-char hex private key for local experiment only. Do not use real wallet private keys.",
    )
    run_experiment(parser.parse_args())
